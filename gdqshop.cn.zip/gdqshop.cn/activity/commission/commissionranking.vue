<template>
<block v-if="isload">
<view class="container"  >
	<view class="contentbox">
		<image :src="pre_url + '/static/imgsrc/rank_notext.png'" mode="widthFix">
			<view class="title">
				<view class="t1">{{sysset.rank_title||'业绩排行榜'}}</view>
				<view class="t2">{{sysset.rank_desc||'历史累积榜单'}}</view>
			</view>
			<view class="top">
				<view class="t1">
					<view class="label">我的佣金</view>	
					<view class="value">{{commission}}</view>	
				</view>
				<view class="t2">
					<text style="color: #9e9e9e;">	累计佣金：</text>{{totalcommission}}
				</view>
			</view>
			
			<view class="content">
			
				<view class="tab1" v-if="sysset.rank_type.length > 1">
					<block v-for="(item, index) in sysset.rank_type" :key="index" >
						<view :class="'t1 '+(item==ranktype?'on':'')" :style="{color:(item==ranktype?t('color1'):'')}" :data-ranktype = "item" @tap="toranktype">{{item==1?'累计佣金':(item==2?'自购订单金额':'')}}		
						<view class="before" v-if="item==ranktype" :style="'border-bottom:1rpx solid '+t('color1')"></view>
						
						</view>
					</block>
				</view>
				
				<view class="tab">
					<view class="t1">排名</view>
					<view class="t2">姓名</view>
					<view class="t3" >{{ranktype==1?'累计佣金':(ranktype==2?'自购订单金额':'')}}</view>
				</view>
			
				<view class="itembox">	
					<block v-for="(item, index) in datalist" :key="index" >
					<view class="item" :style="index < 3 ?'margin-top:20rpx':''">
							<view class="t1" v-if="index<3"><image :src="pre_url+ '/static/img/comrank'+index+'.png'"></view>
							<view class="t1" v-else>{{index+1}}</view>
							<view class="t2"><image :src="item.headimg">{{item.nickname}}</view>
							<text class="t3" :style="{color:t('color1')}"> {{ranktype==1?item.sumcommission:(ranktype==2?item.sumtotalprice:'')}}</text>
					</view>
					</block>
				</view>
			</view>
	</view>

	<nodata v-if="nodata"></nodata>
	<nomore v-if="nomore"></nomore>
	<loading v-if="loading"></loading>
	<dp-tabbar :opt="opt"></dp-tabbar>
	<popmsg ref="popmsg"></popmsg>
</view>
</block>
</template>

<script>
var app = getApp();

export default {
  data() {
    return {
			opt:{},
			loading:false,
      isload: false,
			menuindex:-1,
			pre_url:app.globalData.pre_url,
      nodata: false,
      nomore: false,
      datalist: [],
			textset:{},
      pagenum: 1,
			totalcommission:0,
			commission:0,
			rank_type:[],
			sysset:[],
			ranktype:1
    };
  },

  onLoad: function (opt) {
		this.opt = app.getopts(opt);
		var that = this;
		this.getdata();
  },
	onPullDownRefresh: function () {
		this.getdata();
	},
  onReachBottom: function () {
    if (!this.nodata && !this.nomore) {
      this.pagenum = this.pagenum + 1;
      this.getdata(true);
    }
  },
  methods: {
    getdata: function (loadmore) {
			if(!loadmore){
				this.pagenum = 1;
				this.datalist = [];
			}
      var that = this;
      var pagenum = that.pagenum;
			that.loading = true;
			that.nodata = false;
      that.nomore = false;
			var ranktype = that.ranktype;
			
      app.post('ApiAgent/commissionrank', {ranktype:ranktype,pagenum: pagenum}, function (res) {
				that.loading = false;
        var data = res.data.data;
				that.totalcommission = res.data.totalcommission
				that.commission = res.data.commission
				that.rank_type = res.data.rank_type
				that.sysset = res.data.sysset
				if(res.data.status==0){
						app.alert('排行榜未开启')
				}
        if (pagenum == 1) {
					that.textset = app.globalData.textset;
					uni.setNavigationBarTitle({
						title: that.t('佣金') + '排行'
					});
          that.datalist = data;
          if (data.length == 0) {
            that.nodata = true;
          }
					that.loaded();
        }else{
          if (data.length == 0) {
            that.nomore = true;
          } else {
            var datalist = that.datalist;
            var newdata = datalist.concat(data);
            that.datalist = newdata;
          }
        }
      });
    },
		toranktype:function (e) {
			var that=this
			var ranktype = e.currentTarget.dataset.ranktype;
			that.ranktype = ranktype
			that.getdata()
		}
  }
};
</script>
<style>
/* .container{ padding: 20rpx; background: #FC3B36;} */
.contentbox{ border-radius: 20rpx; width: 100%;}
.contentbox image{ border-top-left-radius: 10rpx; border-top-right-radius: 10rpx; width: 100%; border:none; display: block;}

.content{ background: #fff; display: flex; align-items: center; flex-direction: column; }

.top{ margin-top: -45rpx; border-radius: 10rpx; display: flex;  display: flex;flex-direction: column;background-color: #fff;border-radius: 50rpx 50rpx 0 0;padding: 40rpx 50rpx 40rpx 50rpx;box-shadow: 0 -20rpx 32rpx rgb(144 78 43 / 0.15);position: relative;z-index: 10;}
.top .t1 .label{color: #9e9e9e;}
.top .t1 .value{font-size: 42rpx;color: #FF5D1D;font-weight: 700;}
.top .t1 {line-height: 50rpx;}
.top .t2{line-height: 50rpx;margin-top: 20rpx;}
.content .tab{ display: flex; width: 90%; text-align: left;  line-height: 70rpx; margin-top: 20rpx; color: #666;}
.content .tab .t1{ width: 25%;}
.content .tab .t2{ width: 50%;padding-left: 20rpx;}
.content .tab .t3{ width: 30%;}

.content .tab1{ display: flex; border-bottom: 1rpx solid #dedede; width: 90%; height: 100rpx; line-height: 100rpx;}
.content .tab1 .t1{ text-align: center;margin: 0 30rpx; }
.content .tab1 .t1.on{ color:red;}


.content .itembox{width:94%;}
.content .item{width:100%; display:flex;padding:40rpx 20rpx;border-radius:8px;margin-top: 6rpx;align-items:center;}
.itembox .item:first-child{  background-image: linear-gradient(to right , #FFF3E5, #FFFFFC)}
.itembox .item:nth-child(2){ background-image: linear-gradient(to right , #DDECFF, #FFFFFC)}
.itembox .item:nth-child(3){background-image: linear-gradient(to right , #FFE1DE, #FFFFFC)}



.content .item image{ width: 80rpx; height: 80rpx; border-radius: 50%; margin-right: 20rpx; }
.content .item .t1{color:#000000;font-size:30rpx;width: 25%;font-weight: 700;}
.content .item .t2{color:#666666;font-size:24rpx; width: 60%; display: flex; align-items: center;}
.content .item .t3{ width: 30%; font-weight: bold;}

.data-empty{background:#fff}
.title{position: absolute;left: 8%;top: 6%;}
.title .t1{font-size: 48rpx;font-weight: 700;line-height: 80rpx;color: #9C6238;}
.title .t2{font-size: 32rpx;line-height: 60rpx;color: #9C6238;}
</style>